# PCB Handover — Balloon Tracker v7
## Manual Routing Guide for Human

---

## WHAT YOU'RE LOOKING AT

A pico balloon tracker board: ESP32-C3 + LR2021 radio (sub-GHz + 2.4GHz).
80x60mm, 4-layer PCB (JLCPCB stackup).

**Layers:**
1. F.Cu (top) — signal routing
2. In1.Cu — GND power plane (solid zone)
3. In2.Cu — +3V3 power plane (solid zone)
4. B.Cu (bottom) — signal routing

**Parts (20 footprints):**
```
SOLAR(8,8)    U4(10,20)     U1(40,25)      U2(66,14)
               C4(34,23)     R_LED(59,28)   C3(73.5,18)
D1(18,26)     R_DIV2(25,38)  R_DIV1(31,38)
               ANT1(38,40)
               U3(65,40)
               U5(38,50)
               C1(38,53)    J2(48,54)     R_PD(61,51)
               J1(17,52)                   LED1(71,51)  C2(60,47)
```

Key parts:
- U1 = RP2040 (MCU, center)
- U2 = LR2021 radio module (top-right)
- U3 = USB-C connector (mid-right)
- U4 = ESP32-C3 (left)
- U5 = sensor/IMU (bottom-center)
- ANT1 = antenna (mid-bottom)
- J1, J2 = headers (bottom)

---

## WHAT'S ALREADY DONE

- Placement: 20 parts, zero overlaps, verified
- Zones: GND on In1.Cu, +3V3 on In2.Cu (both filled)
- Thermal vias: 36 vias connecting GND/+3V3 SMD pads to inner planes
- RF trace: RF_OUT from U2 to ANT1 (50Ω, 0.39mm width)
- Power routing: VCAP, SOLAR_IN, EN
- Signal routing: 9 of 16 signal nets routed

---

## WHAT YOU NEED TO ROUTE

7 unrouted nets. Coordinates in mm, board origin = top-left corner.

### 1. +3V3 (power bus, many pads)
Pads: U2.13(73.5,13) U4.5(11.1,19.1) U5.2(37.7,49) U5.6(38.3,51) U5.8(37,51)
C2.1(59.2,47) J2.2(50.5,54) R_PD.2(61.5,51) C3.1(73,18) C1.1(37.2,53)
C4.1(33.5,23) U1.1(31.2,19) J1.2(19.5,52) U3.7(60.2,42.2) U3.8(60.2,43.3)
TIP: +3V3 zone on In2.Cu already exists. Just add short tracks from each SMD pad to nearest thermal via. Some may already connect through vias — verify with DRC.

### 2. I2C_SCL
U5.4(39,49) → J2.4(55.6,54) → U1.8(31.2,29.5)
Long diagonal. Try F.Cu first. Crosses other tracks — may need B.Cu with vias.

### 3. LR_BUSY
U2.12(73.5,15) → U1.3(31.2,22)
42mm horizontal. Route on F.Cu above U1.

### 4. LR_DIO0
U2.14(73.5,11) → U1.13(48.8,26.5)
Diagonal around U1. Try F.Cu, use B.Cu if blocked.

### 5. SPI_MOSI
U2.3(58.5,11) → U1.6(31.2,26.5)
Diagonal across board. B.Cu likely needed to avoid crossings.

### 6. UART0_RX
U1.11(48.8,29.5) → J1.5(27.2,52)
Long vertical down to header. B.Cu recommended.

### 7. UART0_TX
U1.12(48.8,28) → J1.4(24.6,52)
Long vertical, parallel to UART0_RX. Route on B.Cu, 0.5mm gap.

---

## ROUTING RULES

Track widths:
- Signal: 0.20mm
- Power: 0.40mm
- RF: 0.39mm (already done)

Via: 0.6mm diameter, 0.3mm drill

Clearance:
- Track-to-track: 0.2mm minimum
- Track-to-pad: 0.25mm minimum
- Via-to-pad: 0.25mm edge-to-edge (NOT center-to-center)

Layer strategy:
- Horizontal routes → F.Cu
- Vertical/diagonal routes → B.Cu
- Use vias only when switching layers (V key in KiCad)
- Through-vias are OK for this board (inner zones have clearance)

---

## HOW TO ROUTE IN KICAD 9

1. Open v_c3_flight_v7_routed.kicad_pcb in KiCad PCB Editor
2. Press R to run DRC — see what's already passing
3. Press X to start interactive router on a pad
4. Route track — click to place corners, V to add via and switch layer
5. Press R after each net to check DRC
6. Save when all 7 nets routed

DRC target:
- 0 shorting_items (CRITICAL)
- 0 tracks_crossing (CRITICAL)
- 0 unconnected_items (CRITICAL)
- Cosmetic warnings (silk, text) = ignore

---

## FILES

- v_c3_flight_v7_routed.kicad_pcb — the board (open this in KiCad 9)
- v_c3_flight_v7_routed.kicad_pro — KiCad project file
- v_c3_rp2040.kicad_sch — schematic (for net verification)
- balloon_symbols.kicad_sym — symbol library
- sym-lib-table — symbol library table
- custom.pretty/ — custom footprints (ESP32-C3, LR2021)
- ROADMAP-v5-pcb.md — full design plan (reference only)

Save routed board as v_c3_flight_v8_manual.kicad_pcb and send back.